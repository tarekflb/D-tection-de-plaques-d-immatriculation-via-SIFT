from pathlib import Path
from PIL import Image

in_dir = Path(r"C:\Users\ASUS\Downloads\cc\License Plates")
out_dir = in_dir / "jpg"
out_dir.mkdir(exist_ok=True)

count = 0
for p in in_dir.rglob("*.webp"):
    img = Image.open(p).convert("RGB")
    out_path = out_dir / (p.stem + ".jpg")
    img.save(out_path, "JPEG", quality=95)
    count += 1

print(f"Converted {count} webp -> jpg in: {out_dir}")